<?php 
//check if current user role is allowed access to the pages
$can_add = ACL::is_allowed("schedule/add");
$can_edit = ACL::is_allowed("schedule/edit");
$can_view = ACL::is_allowed("schedule/view");
$can_delete = ACL::is_allowed("schedule/delete");
?>
<?php
$comp_model = new SharedController;
$page_element_id = "view-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
//Page Data Information from Controller
$data = $this->view_data;
//$rec_id = $data['__tableprimarykey'];
$page_id = $this->route->page_id; //Page id from url
$view_title = $this->view_title;
$show_header = $this->show_header;
$show_edit_btn = $this->show_edit_btn;
$show_delete_btn = $this->show_delete_btn;
$show_export_btn = $this->show_export_btn;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="view"  data-display-type="table" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <script> 
    </script>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title">View  Schedule</h4> 
                    <!--<a class='btn btn-danger' href="?confirm_msg=true">Share this Event</a> -->
 
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
    <div  class="">
        <div class="container">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <?php $this :: display_page_errors(); ?>
                    <div  class="card animated fadeIn page-content">
                        <?php
                        $counter = 0;
                        if(!empty($data)){
                        $rec_id = (!empty($data['id']) ? urlencode($data['id']) : null);
                        $counter++;
                        ?>
                        <div id="page-report-body" class="">
                            <table class="table table-hover table-borderless table-striped">
                                <!-- Table Body Start -->
                                <tbody class="page-data" id="page-data-<?php echo $page_element_id; ?>">
                                    <?php if(isset($_GET['detail']))
                                    { ?>
                                    <tr  class="td-id">
                                        <th class="title"> Id: </th>
                                        <td class="value"> <?php echo $data['id']; ?></td>
                                    </tr>
                                    <tr  class="td-meeting_id">
                                        <th class="title"> Meeting Id: </th>
                                        <td class="value"> <?php echo $data['meeting_id']; ?></td>
                                    </tr>
                                     <?php } ?>
                                    <tr  class="td-meeting_title">
                                        <th class="title"> Meeting Title: </th>
                                        <td class="value">
                                            <span <?php if($can_edit){ ?> data-value="<?php echo $data['meeting_title']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("schedule/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="meeting_title" 
                                                data-title="Enter Meeting Title" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="itable" <?php } ?>>
                                                <?php echo $data['meeting_title']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-meeting_type">
                                        <th class="title"> Meeting Type: </th>
                                        <td class="value">
                                            <span <?php if($can_edit){ ?> data-source='<?php echo json_encode_quote(Menu :: $meeting_type); ?>' 
                                                data-value="<?php echo $data['meeting_type']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("schedule/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="meeting_type" 
                                                data-title="Select a value ..." 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="select" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="itable" <?php } ?>>
                                                <?php echo $data['meeting_type']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-meetinh_roomno">
                                        <th class="title"> Meeting Room: </th>
                                        <td class="value">
                                            <span <?php if($can_edit){ ?> data-source='<?php echo json_encode_quote(Menu :: $meetinh_roomno); ?>' 
                                                data-value="<?php echo $data['meetinh_roomno']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("schedule/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="meetinh_roomno" 
                                                data-title="Select a value ..." 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="select" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="itable" <?php } ?>>
                                                <?php echo $data['meetinh_roomno']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-meeting_link">
                                        <th class="title"> Meeting Link: </th>
                                        <td class="value">
                                            <span <?php if($can_edit){ ?> data-value="<?php echo $data['meeting_link']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("schedule/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="meeting_link" 
                                                data-title="Enter Meeting Link" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="itable" <?php } ?>>
                                                <?php echo $data['meeting_link']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-meeting_guest">
                                        <th class="title"> Meeting Guest: </th>
                                        <td class="value">
                                            <span <?php if($can_edit){ ?> data-value="<?php echo $data['meeting_guest']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("schedule/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="meeting_guest" 
                                                data-title="Enter Meeting Guest" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="itable" <?php } ?>>
                                                <?php echo $data['meeting_guest']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    
                                    <?php if(isset($_GET['detail']))
                                    { ?>
                                    <tr  class="td-meeting_end_timestamp">
                                        <th class="title"> Meeting End Timestamp: </th>
                                        <td class="value">
                                            <a size="sm" class=" page-modal" href="<?php print_link() ?>">
                                                <?php echo $data['meeting_end_timestamp'] ?>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr  class="td-meet_remarks">
                                        <th class="title"> Meet Remarks: </th>
                                        <td class="value">
                                            <span <?php if($can_edit){ ?> data-value="<?php echo $data['meet_remarks']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("schedule/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="meet_remarks" 
                                                data-title="Enter Meet Remarks" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="itable" <?php } ?>>
                                                <?php echo $data['meet_remarks']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-meet_status">
                                        <th class="title"> Meet Status: </th>
                                        <td class="value">
                                            <span <?php if($can_edit){ ?> data-source='<?php echo json_encode_quote(Menu :: $meet_status); ?>' 
                                                data-value="<?php echo $data['meet_status']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("schedule/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="meet_status" 
                                                data-title="Select a value ..." 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="select" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="itable" <?php } ?>>
                                                <?php echo $data['meet_status']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-meeting_notes">
                                        <th class="title"> Meeting Notes: </th>
                                        <td class="value">
                                            <span <?php if($can_edit){ ?> data-value="<?php echo $data['meeting_notes']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("schedule/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="meeting_notes" 
                                                data-title="Browse..." 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="itable" <?php } ?>>
                                                <?php echo $data['meeting_notes']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-meeting_description">
                                        <th class="title"> Meeting Description: </th>
                                        <td class="value">
                                            <span <?php if($can_edit){ ?> data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("schedule/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="meeting_description" 
                                                data-title="Enter Meeting Description" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="textarea" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="itable" <?php } ?>>
                                                <?php echo $data['meeting_description']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                    <tr  class="td-meeting_location">
                                        <th class="title"> Meeting Location: </th>
                                        <td class="value">
                                            <span <?php if($can_edit){ ?> data-value="<?php echo $data['meeting_location']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("schedule/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="meeting_location" 
                                                data-title="Enter Meeting Location" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="text" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="itable" <?php } ?>>
                                                <?php echo $data['meeting_location']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <?php if(isset($_GET['detail']))
                                    { ?>
                                    <tr  class="td-buttons">
                                        <th class="title"> Buttons: </th>
                                        <td class="value"> <?php echo $data['buttons']; ?></td>
                                    </tr>
                                    <tr  class="td-meeting_live_remarks">
                                        <th class="title"> Meeting Live Remarks: </th>
                                        <td class="value"> <?php echo $data['meeting_live_remarks']; ?></td>
                                    </tr>
                                    <tr  class="td-meeting_endtime">
                                        <th class="title"> Meeting Endtime: </th>
                                        <td class="value">
                                            <span <?php if($can_edit){ ?> data-flatpickr="{ minDate: '', maxDate: ''}" 
                                                data-value="<?php echo $data['meeting_endtime']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("schedule/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="meeting_endtime" 
                                                data-title="Enter Meeting Endtime" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="flatdatetimepicker" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="itable" <?php } ?>>
                                                <?php echo $data['meeting_endtime']; ?> 
                                            </span>
                                        </td>
                                    </tr>
                                    <tr  class="td-meeting_starttime">
                                        <th class="title"> Meeting Starttime: </th>
                                        <td class="value">
                                            <span <?php if($can_edit){ ?> data-flatpickr="{ minDate: '', maxDate: ''}" 
                                                data-value="<?php echo $data['meeting_starttime']; ?>" 
                                                data-pk="<?php echo $data['id'] ?>" 
                                                data-url="<?php print_link("schedule/editfield/" . urlencode($data['id'])); ?>" 
                                                data-name="meeting_starttime" 
                                                data-title="Enter Meeting Starttime" 
                                                data-placement="left" 
                                                data-toggle="click" 
                                                data-type="flatdatetimepicker" 
                                                data-mode="popover" 
                                                data-showbuttons="left" 
                                                class="itable" <?php } ?>>
                                                <?php echo $data['meeting_starttime']; ?> 
                                            </span>
                                        </td>
                                    </tr> 
                                    <?php } ?>
                                    <tr  class="td-user_info_username">
                                        <th class="title"> Meeting Scheduled by : </th>
                                        <td class="value"> <?php echo $data['user_info_username']; ?></td>
                                    </tr> 
                                </tbody>
                                <!-- Table Body End -->
                            </table>
                        </div>
                        <div class="p-3 d-flex">
                            <div class="dropup export-btn-holder mx-1">
                                <!--<a href='?detail=t'><button class="btn btn-sm btn-primary  "  >-->
                                <!--    <i class="fa fa-save"></i> View Details-->
                                <!--</button></a>-->
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <?php $export_print_link = $this->set_current_page_link(array('format' => 'print')); ?>
                                    <a class="dropdown-item export-link-btn" data-format="print" href="<?php print_link($export_print_link); ?>" target="_blank">
                                        <img src="<?php print_link('assets/images/print.png') ?>" class="mr-2" /> PRINT
                                        </a>
                                        <?php $export_pdf_link = $this->set_current_page_link(array('format' => 'pdf')); ?>
                                        <a class="dropdown-item export-link-btn" data-format="pdf" href="<?php print_link($export_pdf_link); ?>" target="_blank">
                                            <img src="<?php print_link('assets/images/pdf.png') ?>" class="mr-2" /> PDF
                                            </a>
                                            <?php $export_word_link = $this->set_current_page_link(array('format' => 'word')); ?>
                                            <a class="dropdown-item export-link-btn" data-format="word" href="<?php print_link($export_word_link); ?>" target="_blank">
                                                <img src="<?php print_link('assets/images/doc.png') ?>" class="mr-2" /> WORD
                                                </a>
                                                <?php $export_csv_link = $this->set_current_page_link(array('format' => 'csv')); ?>
                                                <a class="dropdown-item export-link-btn" data-format="csv" href="<?php print_link($export_csv_link); ?>" target="_blank">
                                                    <img src="<?php print_link('assets/images/csv.png') ?>" class="mr-2" /> CSV
                                                    </a>
                                                    <?php $export_excel_link = $this->set_current_page_link(array('format' => 'excel')); ?>
                                                    <a class="dropdown-item export-link-btn" data-format="excel" href="<?php print_link($export_excel_link); ?>" target="_blank">
                                                        <img src="<?php print_link('assets/images/xsl.png') ?>" class="mr-2" /> EXCEL
                                                        </a>
                                                    </div>
                                                </div>
                                                <?php if($can_edit){ ?>
                                                <!--<a class="btn btn-sm btn-info"  href="<?php print_link("schedule/edit/$rec_id"); ?>">-->
                                                <!--    <i class="fa fa-edit"></i> Edit-->
                                                <!--</a>-->
                                                <?php } ?>
                                                <?php if($can_delete){ ?>
                                                <!--<a class="btn btn-sm btn-danger record-delete-btn mx-1"  href="<?php print_link("schedule/delete/$rec_id/?csrf_token=$csrf_token&redirect=$current_page"); ?>" data-prompt-msg="Are you sure you want to delete this record?" data-display-style="modal">-->
                                                <!--    <i class="fa fa-times"></i> Delete-->
                                                <!--</a>-->
                                                <?php } ?>
                                            </div>
                                            <?php
                                            }
                                            else{
                                            ?>
                                            <!-- Empty Record Message -->
                                            <div class="text-muted p-3">
                                                <i class="fa fa-ban"></i> No Record Found
                                            </div>
                                            <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
