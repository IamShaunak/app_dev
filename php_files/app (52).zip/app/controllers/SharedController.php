<?php 

/**
 * SharedController Controller
 * @category  Controller / Model
 */
class SharedController extends BaseController{
	
	/**
     * user_info_user_role_id_option_list Model Action
     * @return array
     */
	function user_info_user_role_id_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT role_id AS value, role_name AS label FROM roles";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * user_info_admin_id_option_list Model Action
     * @return array
     */
	function user_info_admin_id_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT id AS value,username AS label FROM user_info WHERE ".((USER_ROLE==1)?"id=".USER_ID:"id>0")." AND user_role_id=1 ORDER BY username ASC";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * user_info_username_value_exist Model Action
     * @return array
     */
	function user_info_username_value_exist($val){
		$db = $this->GetModel();
		$db->where("username", $val);
		$exist = $db->has("user_info");
		return $exist;
	}

	/**
     * user_info_email_id_value_exist Model Action
     * @return array
     */
	function user_info_email_id_value_exist($val){
		$db = $this->GetModel();
		$db->where("email_id", $val);
		$exist = $db->has("user_info");
		return $exist;
	}

}
