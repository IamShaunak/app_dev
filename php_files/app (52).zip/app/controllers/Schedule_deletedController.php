<?php 
/**
 * Schedule deleted Page Controller
 * @category  Controller
 */
class Schedule_deletedController extends SecureController{
	function __construct(){
		parent::__construct();
		$this->tablename = "schedule_deleted";
	}
	/**
     * List page records
     * @param $fieldname (filter record by a field) 
     * @param $fieldvalue (filter field value)
     * @return BaseView
     */
	function index($fieldname = null , $fieldvalue = null){
		$request = $this->request;
		$db = $this->GetModel();
		$tablename = $this->tablename;
		$fields = array("schedule_deleted.id", 
			"user_info.username AS user_info_username", 
			"user_info2.username AS user_info2_username", 
			"user_info.mobile AS user_info_mobile", 
			"schedule_deleted.meeting_title", 
			"schedule_deleted.meeting_guest", 
			"schedule_deleted.meeting_starttime", 
			"schedule_deleted.meeting_endtime", 
			"schedule_deleted.meeting_link", 
			"schedule_deleted.meetinh_roomno", 
			"schedule_deleted.meeting_location", 
			"schedule_deleted.meeting_description", 
			"schedule_deleted.meeting_notes", 
			"schedule_deleted.meet_status", 
			"schedule_deleted.meeting_end_timestamp", 
			"schedule_deleted.buttons");
		$pagination = $this->get_pagination(MAX_RECORD_COUNT); // get current pagination e.g array(page_number, page_limit)
	#Statement to execute before list record
	if(USER_ROLE==1){
    $db->where("DATE(meeting_starttime)",date("Y-m-d"));
    $db->where("schedule_deleted.admin_id",USER_ID);
}	if(USER_ROLE==2){ 
    if(isset($_GET['admin_id']) && $_GET['admin_id']!=get_active_user("admin_id") && $_GET['admin_id']!="All"){
    $db->where("schedule_deleted.admin_id",$_GET['admin_id']);
    $db->where("schedule_deleted.user_id",USER_ID);
        
    }else if(isset($_GET['admin_id']) && $_GET['admin_id']!=get_active_user("admin_id") && $_GET['admin_id']=="All"){
        
    $db->where("schedule_deleted.user_id",USER_ID);
    }else{
    $db->where("schedule_deleted.admin_id",get_active_user("admin_id"));
        
    }
}
if(isset($_GET['schedule_meeting_starttime'])){
    $db->where("DATE(meeting_starttime)",$_GET['schedule_meeting_starttime']);
}else{ 
    
}
	# End of before list statement
		//search table record
		if(!empty($request->search)){
			$text = trim($request->search); 
			$search_condition = "(
				schedule_deleted.id LIKE ? OR 
				schedule_deleted.meeting_id LIKE ? OR 
				user_info.username LIKE ? OR  
				schedule_deleted.meeting_title LIKE ? OR 
				schedule_deleted.meeting_guest LIKE ? OR 
				schedule_deleted.meeting_starttime LIKE ? OR 
				schedule_deleted.meeting_endtime LIKE ? OR 
				schedule_deleted.meeting_type LIKE ? OR 
				schedule_deleted.meeting_link LIKE ? OR 
				schedule_deleted.meetinh_roomno LIKE ? OR 
				schedule_deleted.meeting_location LIKE ? OR 
				schedule_deleted.meeting_description LIKE ? OR 
				schedule_deleted.meeting_notes LIKE ? OR 
				schedule_deleted.meet_status LIKE ? OR 
				schedule_deleted.meeting_end_timestamp LIKE ? OR 
				schedule_deleted.meet_remarks LIKE ? OR 
				schedule_deleted.buttons LIKE ? OR 
				schedule_deleted.meeting_live_remarks LIKE ? OR 
				schedule_deleted.user_id LIKE ? OR 
				schedule_deleted.admin_id LIKE ? OR 
				user_info.id LIKE ? OR 
				user_info.email_id LIKE ? OR 
				user_info.mac_id LIKE ? OR 
				user_info.password LIKE ? OR 
				user_info.user_role_id LIKE ? OR 
				user_info.admin_id LIKE ?
			)";
			$search_params = array(
				"%$text%","%$text%","%$text%" ,"%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%"
			);
			//setting search conditions
			$db->where($search_condition, $search_params);
			 //template to use when ajax search
			$this->view->search_template = "schedule_deleted/search.php";
		}
		$db->join("user_info", "schedule_deleted.user_id = user_info.id", "INNER");
		$db->join("user_info as user_info2", "schedule_deleted.admin_id = user_info2.id", "INNER");
		if(!empty($request->orderby)){
			$orderby = $request->orderby;
			$ordertype = (!empty($request->ordertype) ? $request->ordertype : ORDER_TYPE);
			$db->orderBy($orderby, $ordertype);
		}
		else{
			$db->orderBy("schedule_deleted.id", ORDER_TYPE);
		}
		if($fieldname){
			$db->where($fieldname , $fieldvalue); //filter by a single field name
		}
		$tc = $db->withTotalCount();
		$records = $db->get($tablename, $pagination, $fields);
		$records_count = count($records);
		$total_records = intval($tc->totalCount);
		$page_limit = $pagination[1];
		$total_pages = ceil($total_records / $page_limit);
		$data = new stdClass;
		$data->records = $records;
		$data->record_count = $records_count;
		$data->total_records = $total_records;
		$data->total_page = $total_pages;
		if($db->getLastError()){
			$this->set_page_error();
		}
		$page_title = $this->view->page_title = "Schedule deleted";
		$this->view->report_filename = date('Y-m-d') . '-' . $page_title;
		$this->view->report_title = $page_title;
		$this->view->report_layout = "report_layout.php";
		$this->view->report_paper_size = "A4";
		$this->view->report_orientation = "portrait";
		$this->render_view("schedule_deleted/list.php", $data); //render the full page
	}
	/**
     * View record detail 
	 * @param $rec_id (select record by table primary key) 
     * @param $value value (select record by value of field name(rec_id))
     * @return BaseView
     */
	function view($rec_id = null, $value = null){
		$request = $this->request;
		$db = $this->GetModel();
		$rec_id = $this->rec_id = urldecode($rec_id);
		$tablename = $this->tablename;
		$fields = array("schedule_deleted.id", 
			"schedule_deleted.meeting_id", 
			"schedule_deleted.meeting_title", 
			"schedule_deleted.meeting_type", 
			"schedule_deleted.meetinh_roomno", 
			"schedule_deleted.meeting_link", 
			"schedule_deleted.meeting_guest", 
			"schedule_deleted.meeting_end_timestamp", 
			"schedule_deleted.meet_remarks", 
			"schedule_deleted.meet_status", 
			"schedule_deleted.meeting_notes", 
			"schedule_deleted.meeting_description", 
			"schedule_deleted.meeting_location", 
			"schedule_deleted.buttons", 
			"schedule_deleted.meeting_live_remarks", 
			"schedule_deleted.meeting_endtime", 
			"schedule_deleted.meeting_starttime", 
			"schedule_deleted.user_id", 
			"schedule_deleted.admin_id", 
			"user_info.id AS user_info_id", 
			"user_info.username AS user_info_username", 
			"user_info.email_id AS user_info_email_id", 
			"user_info.mac_id AS user_info_mac_id", 
			"user_info.password AS user_info_password", 
			"user_info.user_role_id AS user_info_user_role_id", 
			"user_info.admin_id AS user_info_admin_id");
		if($value){
			$db->where($rec_id, urldecode($value)); //select record based on field name
		}
		else{
			$db->where("schedule_deleted.id", $rec_id);; //select record based on primary key
		}
		$db->join("user_info", "schedule_deleted.user_id = user_info.id", "INNER ");  
		$record = $db->getOne($tablename, $fields );
		if($record){
			$page_title = $this->view->page_title = "View  Schedule deleted";
		$this->view->report_filename = date('Y-m-d') . '-' . $page_title;
		$this->view->report_title = $page_title;
		$this->view->report_layout = "report_layout.php";
		$this->view->report_paper_size = "A4";
		$this->view->report_orientation = "portrait";
		}
		else{
			if($db->getLastError()){
				$this->set_page_error();
			}
			else{
				$this->set_page_error("No record found");
			}
		}
		return $this->render_view("schedule_deleted/view.php", $record);
	}
	/**
     * Insert new record to the database table
	 * @param $formdata array() from $_POST
     * @return BaseView
     */
	function add($formdata = null){
		if($formdata){
			$db = $this->GetModel();
			$tablename = $this->tablename;
			$request = $this->request;
			//fillable fields
			$fields = $this->fields = array("meeting_title","meeting_guest","meeting_starttime","meeting_endtime","meeting_type","meeting_link","meetinh_roomno","meeting_location","meeting_description","meeting_notes","meet_remarks");
			$postdata = $this->format_request_data($formdata);
			$this->rules_array = array(
				'meeting_title' => 'required',
				'meeting_starttime' => 'required',
			);
			$this->sanitize_array = array(
				'meeting_title' => 'sanitize_string',
				'meeting_guest' => 'sanitize_string',
				'meeting_starttime' => 'sanitize_string',
				'meeting_endtime' => 'sanitize_string',
				'meeting_type' => 'sanitize_string',
				'meeting_link' => 'sanitize_string',
				'meetinh_roomno' => 'sanitize_string',
				'meeting_location' => 'sanitize_string',
				'meeting_notes' => 'sanitize_string',
				'meet_remarks' => 'sanitize_string',
			);
			$this->filter_vals = true; //set whether to remove empty fields
			$modeldata = $this->modeldata = $this->validate_form($postdata);
			if($this->validated()){
		# Statement to execute before adding record
		function isTimePeriodBusy($meeting_starttime, $meeting_endtime, $existingMeetings) {
    foreach ($existingMeetings as $meeting) {
        $existing_start = $meeting['meeting_starttime'];
        $existing_end = $meeting['meeting_endtime'];
        // Check for overlap
        if ($meeting_starttime < $existing_end && $meeting_endtime > $existing_start) {
            return true; // There is an overlap
        }
    }
    return false; // No overlap found
}
// Example usage
$meeting_starttime = $modeldata['meeting_starttime'];
$meeting_endtime   = $modeldata['meeting_endtime'];
$db->where("admin_id",get_active_user("admin_id"));
$existingMeetings = $db->get($tablename,999999,"meeting_starttime,meeting_endtime");
if (isTimePeriodBusy($meeting_starttime, $meeting_endtime, $existingMeetings)) {
    $this->set_flash_msg("Admin is already busy in the following time", "danger");
    return  $this->redirect("$tablename");
} 
$modeldata['user_id']  = USER_ID;
$modeldata['admin_id'] = get_active_user("admin_id");
		# End of before add statement
				$rec_id = $this->rec_id = $db->insert($tablename, $modeldata);
				if($rec_id){
		# Statement to execute after adding record
		$html='<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meeting Notification</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333333;
        }
        p {
            color: #666666;
            line-height: 1.6;
        }
        .detail {
            margin-bottom: 15px;
        }
        .label {
            font-weight: bold;
            color: #333333;
        }
        .attachments a {
            color: #1a73e8;
            text-decoration: none;
        }
        .attachments a:hover {
            text-decoration: underline;
        }
        .button {
            display: inline-block;
            background-color: #1a73e8;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Meeting Notification</h1>
        <p>Hello,</p>
        <p>You have a schedule_deletedd meeting with the following details:</p>
        <div class="detail">
        <span class="label">Meeting Title:</span> '.$modeldata['meeting_title'].'
        </div>
        <div class="detail">
        <span class="label">Guest:</span> '.$modeldata['meeting_guest'].'
        </div>
        <div class="detail">
        <span class="label">Date & Time:</span> '.date("d-M-Y H:i:s",strtotime($modeldata['meeting_starttime'])).' - '.date("d-M-Y H:i:s",strtotime($modeldata['meeting_endtime'])).'
        </div> 
        <div class="detail">
        <span class="label">Remarks:</span> '.$modeldata['meet_remarks'].'
        </div>
        <p>We look forward to your participation.</p>
        <p>Best regards,</p>
        <p>The Team</p>
    </div>
</body>
</html>';
#please make sure you have configure the mail settings
$mailtitle      = "Meeting Notification";
$mailbody       = $html;
$db->where("id",$modeldata['admin_id']);
$email          = $db->getOne("user_info","*")['email_id'];
$receiver_email = $email;
$mailer         = new Mailer;
$mailer->send_mail($receiver_email, $mailtitle, $mailbody);
		# End of after add statement
					$this->set_flash_msg("Record added successfully", "success");
					return	$this->redirect("schedule_deleted");
				}
				else{
					$this->set_page_error();
				}
			}
		}
		$page_title = $this->view->page_title = "Add New Schedule deleted";
		$this->render_view("schedule_deleted/add.php");
	}
	/**
     * Update table record with formdata
	 * @param $rec_id (select record by table primary key)
	 * @param $formdata array() from $_POST
     * @return array
     */
	function edit($rec_id = null, $formdata = null){
		$request = $this->request;
		$db = $this->GetModel();
		$this->rec_id = $rec_id;
		$tablename = $this->tablename;
		 //editable fields
		$fields = $this->fields = array("id","meeting_title","meeting_guest","meeting_starttime","meeting_endtime","meeting_type","meeting_link","meetinh_roomno","meeting_location","meeting_description","meeting_notes","meet_remarks");
		if($formdata){
			$postdata = $this->format_request_data($formdata);
			$this->rules_array = array(
				'meeting_title' => 'required',
				'meeting_starttime' => 'required', 
			);
			$this->sanitize_array = array(
				'meeting_title' => 'sanitize_string',
				'meeting_guest' => 'sanitize_string',
				'meeting_starttime' => 'sanitize_string',
				'meeting_endtime' => 'sanitize_string',
				'meeting_type' => 'sanitize_string',
				'meeting_link' => 'sanitize_string',
				'meetinh_roomno' => 'sanitize_string',
				'meeting_location' => 'sanitize_string',
				'meeting_notes' => 'sanitize_string',
				'meet_remarks' => 'sanitize_string', 
			);
			$modeldata = $this->modeldata = $this->validate_form($postdata);
			if($this->validated()){
				$db->where("schedule_deleted.id", $rec_id);;
				$bool = $db->update($tablename, $modeldata);
				$numRows = $db->getRowCount(); //number of affected rows. 0 = no record field updated
				
				$db->where("schedule_deleted.id", $rec_id);;
				$x=$db->getOne("schedule_deleted","*");
				unset($x['id']);
				$db->insert("schedule",$x); 
				$db->where("schedule_deleted.id", $rec_id); 
				$db->delete("schedule_deleted" );
				if($bool && $numRows){
					$this->set_flash_msg("Record updated successfully", "success");
					return $this->redirect("schedule_deleted");
				}
				else{
					if($db->getLastError()){
						$this->set_page_error();
					}
					elseif(!$numRows){
						//not an error, but no record was updated
						$page_error = "No record updated";
						$this->set_page_error($page_error);
						$this->set_flash_msg($page_error, "warning");
						return	$this->redirect("schedule_deleted");
					}
				}
			}
		}
		$db->where("schedule_deleted.id", $rec_id);;
		$data = $db->getOne($tablename, $fields);
		$page_title = $this->view->page_title = "Edit  Schedule deleted";
		if(!$data){
			$this->set_page_error();
		}
		return $this->render_view("schedule_deleted/edit.php", $data);
	}
	/**
     * Delete record from the database
	 * Support multi delete by separating record id by comma.
     * @return BaseView
     */
	function delete($rec_id = null){
		Csrf::cross_check();
		$request = $this->request;
		$db = $this->GetModel();
		$tablename = $this->tablename;
		$this->rec_id = $rec_id;
		//form multiple delete, split record id separated by comma into array
		$arr_rec_id = array_map('trim', explode(",", $rec_id));
		$db->where("schedule_deleted.id", $arr_rec_id, "in");
		$bool = $db->delete($tablename);
		if($bool){
			$this->set_flash_msg("Record deleted successfully", "success");
		}
		elseif($db->getLastError()){
			$page_error = $db->getLastError();
			$this->set_flash_msg($page_error, "danger");
		}
		return	$this->redirect("schedule_deleted");
	}
	/**
     * Update table record with formdata
	 * @param $rec_id (select record by table primary key)
	 * @param $formdata array() from $_POST
     * @return array
     */
	function meeting_end($rec_id = null, $formdata = null){
		$request = $this->request;
		$db = $this->GetModel();
		$this->rec_id = $rec_id;
		$tablename = $this->tablename;
		 //editable fields
		$fields = $this->fields = array("id","meeting_end_timestamp");
		if($formdata){
			$postdata = $this->format_request_data($formdata);
			$this->rules_array = array(
				'meeting_end_timestamp' => 'required',
			);
			$this->sanitize_array = array(
				'meeting_end_timestamp' => 'sanitize_string',
			);
			$modeldata = $this->modeldata = $this->validate_form($postdata);
			if($this->validated()){
		# Statement to execute after adding record
		$modeldata['meet_status'] = 'Ended';
		# End of before update statement
				$db->where("schedule_deleted.id", $rec_id);;
				$bool = $db->update($tablename, $modeldata);
				$numRows = $db->getRowCount(); //number of affected rows. 0 = no record field updated
				if($bool && $numRows){
					$this->set_flash_msg("Record updated successfully", "success");
					return $this->redirect("schedule_deleted");
				}
				else{
					if($db->getLastError()){
						$this->set_page_error();
					}
					elseif(!$numRows){
						//not an error, but no record was updated
						$page_error = "No record updated";
						$this->set_page_error($page_error);
						$this->set_flash_msg($page_error, "warning");
						return	$this->redirect("schedule_deleted");
					}
				}
			}
		}
		$db->where("schedule_deleted.id", $rec_id);;
		$data = $db->getOne($tablename, $fields);
		$page_title = $this->view->page_title = "Edit  Schedule deleted";
		if(!$data){
			$this->set_page_error();
		}
		return $this->render_view("schedule_deleted/meeting_end.php", $data);
	}
	/**
     * Update table record with formdata
	 * @param $rec_id (select record by table primary key)
	 * @param $formdata array() from $_POST
     * @return array
     */
	function remarks($rec_id = null, $formdata = null){
		$request = $this->request;
		$db = $this->GetModel();
		$this->rec_id = $rec_id;
		$tablename = $this->tablename;
		 //editable fields
		$fields = $this->fields = array("id","meeting_live_remarks");
		if($formdata){
			$postdata = $this->format_request_data($formdata);
			$this->rules_array = array(
				'meeting_live_remarks' => 'required',
			);
			$this->sanitize_array = array(
				'meeting_live_remarks' => 'sanitize_string',
			);
			$modeldata = $this->modeldata = $this->validate_form($postdata);
			if($this->validated()){
				$db->where("schedule_deleted.id", $rec_id);;
				$bool = $db->update($tablename, $modeldata);
				$numRows = $db->getRowCount(); //number of affected rows. 0 = no record field updated
				if($bool && $numRows){
					$this->set_flash_msg("Record updated successfully", "success");
					return $this->redirect("schedule_deleted");
				}
				else{
					if($db->getLastError()){
						$this->set_page_error();
					}
					elseif(!$numRows){
						//not an error, but no record was updated
						$page_error = "No record updated";
						$this->set_page_error($page_error);
						$this->set_flash_msg($page_error, "warning");
						return	$this->redirect("schedule_deleted");
					}
				}
			}
		}
		$db->where("schedule_deleted.id", $rec_id);;
		$data = $db->getOne($tablename, $fields);
		$page_title = $this->view->page_title = "Edit  Schedule deleted";
		if(!$data){
			$this->set_page_error();
		}
		return $this->render_view("schedule_deleted/remarks.php", $data);
	}
}
