<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbartopleft = array(
		array(
			'path' => 'schedule', 
			'label' => 'Schedule', 
			'icon' => ''
		),	
		array(
			'path' => 'schedule/list/?closed=true', 
			'label' => 'Completed Meetings', 
			'icon' => ''
		),	
		
		array(
			'path' => 'schedule_deleted', 
			'label' => 'Rejected Meetings', 
			'icon' => ''
		),
		
		array(
			'path' => 'user_info', 
			'label' => 'My Users', 
			'icon' => ''
		),
		
		array(
			'path' => 'role_permissions', 
			'label' => 'Role Permissions', 
			'icon' => ''
		),
		
		array(
			'path' => 'roles', 
			'label' => 'Roles', 
			'icon' => ''
		)
	);
		
	
	
			public static $meeting_type = array(
		array(
			"value" => "Online", 
			"label" => "Online", 
		),
		array(
			"value" => "Offline", 
			"label" => "Offline", 
		),);
		
			public static $meetinh_roomno = array(
		array(
			"value" => "Conference Room 1", 
			"label" => "Conference Room 1", 
		),
		array(
			"value" => "Conference Room 2", 
			"label" => "Conference Room 2", 
		),
		array(
			"value" => "Conference Room 3", 
			"label" => "Conference Room 3", 
		),
		array(
			"value" => "Conference Room 4", 
			"label" => "Conference Room 4", 
		),);
		
			public static $meet_status = array(
		array(
			"value" => "End", 
			"label" => "End", 
		),
		array(
			"value" => "Prolong", 
			"label" => "Prolong", 
		),);
		
}