<?php

/**
 * Info Contoller Class
 * @category  Controller
 */

class ApiController extends BaseController
{
    
    
    function end_meet($id){
        

		date_default_timezone_set('Asia/Calcutta');
	     $db=$this->GetModel();
		$modeldata['meet_status'] = 'Ended';
		$modeldata['meeting_endtime']=date("Y-m-d H:i:s");
		
		# End of before update statement
				$db->where("schedule.id", $id);;
				$bool = $db->update("schedule", $modeldata);
				
				?>
				<script>
				    location.href='<?php echo SITE_ADDR ?>';
				</script>
				<?php
    }

	/**
	 * call model action to retrieve data
	 * @return json data
	 */
	 function share($id){
	     $db=$this->GetModel();
	     $db->where("id",$id);
	     $d=$db->getOne("schedule","*");
	     
	     render_json(["msg"=>"Meeting Title : ".$d['meeting_title']."\nMeeting Type : ".$d['meeting_type']."\nMeeting Room : ".$d['meetinh_roomno']."\nMeeting Link : ".$d['meeting_link']."\nMeeting Guest : ".$d['meeting_guest']."\nMeeting Location : ".$d['meeting_location']."\nMeeting Start Time : ".$d['meeting_starttime']."\nMeeting End Time : ".$d['meeting_endtime']]);
	 }
	 function send_reminder_email(){
	     $db=$this->GetModel();
	     date_default_timezone_set('Asia/Kolkata');
	     $datetime=date("Y-m-d H:i",strtotime(date("Y-m-d H:i"))+(15*60));
	     $db->where("meeting_starttime >= '$datetime:00' AND meeting_starttime <= '$datetime:59'");
	     $recs=$db->get("schedule",9999,"*");
	     foreach($recs as $modeldata){
	         $html='<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meeting Notification</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333333;
        }
        p {
            color: #666666;
            line-height: 1.6;
        }
        .detail {
            margin-bottom: 15px;
        }
        .label {
            font-weight: bold;
            color: #333333;
        }
        .attachments a {
            color: #1a73e8;
            text-decoration: none;
        }
        .attachments a:hover {
            text-decoration: underline;
        }
        .button {
            display: inline-block;
            background-color: #1a73e8;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Meeting Notification</h1>
        <p>Hello,</p>
        <p>You have a scheduled meeting with the following details:</p>
        
        <div class="detail">
        <span class="label">Meeting Title:</span> '.$modeldata['meeting_title'].'
        </div>
        <div class="detail">
        <span class="label">Guest:</span> '.$modeldata['meeting_guest'].'
        </div>
        <div class="detail">
        <span class="label">Date & Time:</span> '.date("d-M-Y H:i:s",strtotime($modeldata['meeting_starttime'])).' - '.date("d-M-Y H:i:s",strtotime($modeldata['meeting_endtime'])).'
        </div> 
        <div class="detail">
        <span class="label">Attachments:</span>
        
            <ul>';
            $exp=explode(",",$modeldata['meeting_notes']);
            $no=0;
            foreach($exp as $file){
                $no++;
                $html.='<li><a href="'.$file.'">Attachment '.$no.'</a></li>';
            }
            
            $html.='
            </ul>
            
            
        </div>
        <div class="detail">
        <span class="label">Remarks:</span> '.$modeldata['meet_remarks'].'
        </div>
        <div class="detail"> ';
        if($modeldata['meeting_type']=="Offline"){
            
                $html.='<span class="label">Location:</span> '.$modeldata['meeting_location'].'</span>';
        }else{
            
                $html.='<span class="label">Link:</span> <a href="'.$modeldata['meeting_link'].'" class="button">Join Meeting</a></span>';
        }
        $html.=' 
        </div>
        
        <p>We look forward to your participation.</p>
        <p>Best regards,</p>
        <p>The Team</p>
        
    </div>
</body>
</html>';



#please make sure you have configure the mail settings
$mailtitle      = "Meeting Reminder";
$mailbody       = $html;
$db->where("id",$modeldata['admin_id']);
$email          = $db->getOne("user_info","*")['email_id'];
$receiver_email = $email;
$mailer         = new Mailer;
$mailer->send_mail($receiver_email, $mailtitle, $mailbody);




	     }
	 }
	 function update_status(){
	     $db=$this->GetModel();
	     date_default_timezone_set('Asia/Kolkata');
	      echo  $datetime= date("Y-m-d H:i",strtotime(date("Y-m-d H:i"))+(0));
	     $db->where("meeting_starttime >= '$datetime:00' AND meeting_starttime <= '$datetime:59'");
	     $db->where("meet_status","Ongoing","!=");
	     $db->update("schedule",["meet_status"=>"Ongoing"]); 
	   //  print_r($db);
	     $db->where("meeting_endtime >= '$datetime:00' AND meeting_endtime <= '$datetime:59'");
	     $db->where("meet_status","Ongoing" );
	     $db->update("schedule",["meet_status"=>"Prolong"]);  
	     
	 }
	function json($action, $arg1 = null, $arg2 = null)
	{
		$model = new SharedController;
		$args = array($arg1, $arg2);
		$data = call_user_func_array(array($model, $action), $args);
		render_json($data);
	}
}
